

<?php $__env->startSection('content'); ?>

  <main id="main" data-aos="fade" data-aos-delay="1500">

    <!-- ======= Gallery Section ======= -->
    <section id="gallery" class="gallery">
      <div class="container-fluid">

        <div class="row gy-4 justify-content-center">
          <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="col-xl-3 col-lg-4 col-md-6">
            <div class="gallery-item h-100">
              <img src="https://source.unsplash.com/1920x1440?<?php echo e($product->category->name); ?>" class="img-fluid" alt="">
              <div class="gallery-links d-flex align-items-center justify-content-center">
                <a href="https://source.unsplash.com/1920x1440?<?php echo e($product->category->name); ?>" title="Gallery 1" class="glightbox preview-link">
                  <i class="bi bi-arrows-angle-expand"></i></a>
                <a href="/product/detail/<?php echo e($product->id); ?>" class="details-link"><i class="bi bi-link-45deg"></i></a>
              </div>
            </div>
          </div><!-- End Gallery Item -->
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

      </div>
    </section><!-- End Gallery Section -->

  </main><!-- End #main -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/pengguna/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Kuliah Diah Paramitha\SEMESTER 6\ARKATAMA\PROJECT\snapzone\resources\views/Pengguna/index.blade.php ENDPATH**/ ?>