<!DOCTYPE html>
<html>
<head>
	<?php echo $__env->make('Layouts/Pengguna/Partials/head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>
<body>

	<?php echo $__env->make('Layouts/Pengguna/Partials/navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

	<?php echo $__env->make('Layouts/Pengguna/Partials/hero', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

		<?php echo $__env->yieldContent('content'); ?>

	<?php echo $__env->make('Layouts/Pengguna/Partials/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</body>
</html><?php /**PATH D:\Kuliah Diah Paramitha\SEMESTER 6\ARKATAMA\PROJECT\snapzone\resources\views/layouts/pengguna/main.blade.php ENDPATH**/ ?>